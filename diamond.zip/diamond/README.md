# Diamond

A Pen created on CodePen.

Original URL: [https://codepen.io/editor/Chukwu-chinaecherem-Goodness/pen/019f422b-5158-7dda-b5e1-e04a9ca8dabb](https://codepen.io/editor/Chukwu-chinaecherem-Goodness/pen/019f422b-5158-7dda-b5e1-e04a9ca8dabb).

